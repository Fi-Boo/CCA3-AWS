

class Product:
    def __init__(self, plu, name, price, quantity, sku):
        self.plu = plu
        self.name = name
        self.price = price
        self.quantity = quantity
        self.sku = sku